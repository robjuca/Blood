﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author:     Roberto Oliveira Jucá
----------------------------------------------------------------*/

//----- Include
using System.Reflection;
//---------------------------//

[assembly: AssemblyTitle ("rr Library Message")]
[assembly: AssemblyDescription ("This .NET assembly is a class library.")]
[assembly: AssemblyConfiguration ("Build")]
[assembly: AssemblyCompany ("R&R Soft")]
[assembly: AssemblyProduct ("rr.Library.Message")]
[assembly: AssemblyCopyright ("Roberto Jucá (robjuca@pobox.com) Copyright © R&R Soft 2001")]
[assembly: AssemblyTrademark ("R&R Soft® is a registered trademark of R&R Soft.")]
[assembly: AssemblyCulture ("")]
[assembly: AssemblyVersion ("1.0.2014.11")]
[assembly: AssemblyFileVersion ("1.0.2014.11")]
//---------------------------//