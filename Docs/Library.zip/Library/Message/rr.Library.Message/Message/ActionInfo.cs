﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Message
{
  public class TActionInfo<TActionType>
  {
    #region Property
    public TActionType Action
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TActionInfo (TActionType action)
    {
      Action = action;
    }
    #endregion

    #region Members
    public bool IsAction (TActionType action)
    {
      return (Action.Equals (action));
    }
    #endregion
  };
  //---------------------------//

}  // namespace