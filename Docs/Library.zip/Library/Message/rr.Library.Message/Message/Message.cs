﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;

using rr.Library.Helper;
using rr.Library.Types;
//---------------------------//

namespace rr.Library.Message
{
  public class TMessage<M, A, S, N>
  {
    #region Property
    public TModuleInfo<M> Module
    {
      get;
      private set;
    }

    public TActionInfo<A> Action
    {
      get;
      private set;
    }

    public S Support
    {
      get;
      private set;
    }

    public N Node
    {
      get;
      private set;
    }

    public TValidationResult Result
    {
      get;
      set;
    }

    public DateTime Date
    {
      get;
      private set;
    }

    public Guid MyId
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TMessage (M module, A action, S support, N node, TTypeInfo typeInfo)
      : this ()
    {
      Module = new TModuleInfo<M> (module, typeInfo);
      Action = new TActionInfo<A> (action);
      Support = support;
      Node = node;
    }

    TMessage ()
    {
      Date = DateTime.Now;
      MyId = Guid.Empty;
      Result = TValidationResult.CreateDefault;
    }
    #endregion

    #region Members

    public bool IsModule (M module)
    {
      return (Module.IsModule (module));
    }

    public bool IsAction (A action)
    {
      return (Action.IsAction  (action));
    }

    public void CopyResult (TValidationResult alias)
    {
      if (alias.NotNull ()) {
        Result.CopyFrom (alias);
      }
    }
    #endregion
  };
  //---------------------------//

}  // namespace