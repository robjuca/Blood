﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;

using rr.Library.Helper;
using rr.Library.Types;
//---------------------------//

namespace rr.Library.Message
{
  public class TMessage<TModuleType, TActionType, TSupportType, TNodeType>
  {
    #region Property
    public TModuleInfo<TModuleType> Module
    {
      get;
      private set;
    }

    public TActionInfo<TActionType> Action
    {
      get;
      private set;
    }

    public TSupportType Support
    {
      get;
      private set;
    }

    public TNodeType Node
    {
      get;
      private set;
    }

    public TValidationResult Result
    {
      get;
      set;
    }

    public DateTime Date
    {
      get;
      private set;
    }

    public Guid MyId
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TMessage (TModuleType module, TActionType action, TSupportType support, TNodeType node, TTypeInfo typeInfo)
      : this ()
    {
      Module = new TModuleInfo<TModuleType> (module, typeInfo);
      Action = new TActionInfo<TActionType> (action);
      Support = support;
      Node = node;
    }

    TMessage ()
    {
      Date = DateTime.Now;
      MyId = Guid.Empty;
      Result = TValidationResult.CreateDefault;
    }
    #endregion

    #region Members

    public bool IsModule (TModuleType module)
    {
      return (Module.IsModule (module));
    }

    public bool IsAction (TActionType action)
    {
      return (Action.IsAction  (action));
    }

    public void CopyResult (TValidationResult alias)
    {
      if (alias.NotNull ()) {
        Result.CopyFrom (alias);
      }
    }
    #endregion
  };
  //---------------------------//

}  // namespace