﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using rr.Library.Types;
//---------------------------//

namespace rr.Library.Message
{
  #region Data
  //-----TActionStatus
  public enum TActionStatus
  {
    None,
    Success,
    Error,
  };
  //---------------------------//
  #endregion

  //----- TSupport<A>
  public class TSupport<A> : TSupportBase
  {
    #region Property
    public A Argument
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TSupport (A argument)
      : base ()
    {
      Argument = argument;
    }
    #endregion
  };
  //---------------------------//

  //----- TSupportBase
  public abstract class TSupportBase
  {
    #region Property
    public TActionStatus ActionStatus
    {
      get;
      private set;
    }

    public TErrorMessage ErrorMessage
    {
      get;
    }
    #endregion

    #region Constructor
    public TSupportBase ()
    {
      ActionStatus = TActionStatus.None;

      ErrorMessage = TErrorMessage.CreateDefault;
    }
    #endregion

    #region Members
    public void CopyFrom (TSupportBase alias)
    {
      if (alias != null) {
        ActionStatus = alias.ActionStatus;

        ErrorMessage.CopyFrom (alias.ErrorMessage);
      }
    }

    public void Select (TActionStatus status)
    {
      ActionStatus = status;
    }

    public bool IsActionStatus (TActionStatus status)
    {
      return (ActionStatus == status);
    }
    #endregion
  };
  //---------------------------//

}  // namespace