﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Message
{
  #region Data
  //-----TActionStatus
  public enum TActionStatus
  {
    None,
    Success,
    Error,
  };
  //---------------------------//
  #endregion

  //----- TSupport<A>
  public class TSupport<TArgumentType> : TSupportBase
  {
    #region Property
    public TArgumentType Argument
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TSupport (TArgumentType argument)
      : base ()
    {
      Argument = argument;
    }
    #endregion
  };
  //---------------------------//

  //----- TSupportBase
  public class TSupportBase
  {
    #region Property
    public TActionStatus ActionStatus
    {
      get;
      private set;
    }

    public TErrorMessage ErrorMessage
    {
      get;
    }
    #endregion

    #region Constructor
    public TSupportBase ()
    {
      ActionStatus = TActionStatus.None;

      ErrorMessage = TErrorMessage.CreateDefault;
    }
    #endregion

    #region Members
    public void CopyFrom (TSupportBase alias)
    {
      if (alias.NotNull ()) {
        ActionStatus = alias.ActionStatus;

        ErrorMessage.CopyFrom (alias.ErrorMessage);
      }
    }

    public void Select (TActionStatus status)
    {
      ActionStatus = status;
    }

    public bool IsActionStatus (TActionStatus status)
    {
      return (ActionStatus.Equals (status));
    }
    #endregion
  };
  //---------------------------//

}  // namespace