﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Message
{
  //----- TModuleInfo<S, R>
  public class TModuleInfo<TSenderTtype, TReceiverType>
  {

    public TModuleInfo<TSenderTtype> Sender
    {
      get;
      set;
    }

    public TModuleInfo<TReceiverType> Receiver
    {
      get;
      set;
    }

    #region Constructor
    public TModuleInfo (TSenderTtype sender, TReceiverType receiver)
    {
      Sender = new TModuleInfo<TSenderTtype> (sender);
      Receiver = new TModuleInfo<TReceiverType> (receiver);
    }
    #endregion

    #region Members
    public void SelectSender (TTypeInfo typeInfo)
    {
      Sender.Select (typeInfo);
    }

    public void SelectReceiver (TTypeInfo typeInfo)
    {
      Receiver.Select (typeInfo);
    } 
    #endregion
  };
  //---------------------------//

  //----- TModuleInfo<M>
  public class TModuleInfo<TModuleType>
  {
    #region Property
    public TModuleType Name
    {
      get;
      private set;
    }

    public TTypeInfo TypeInfo
    {
      get;
      private set;
    }

    public Guid Id
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TModuleInfo (TModuleType module)
      : this ()
    {
      Name = module;
    }

    public TModuleInfo (TModuleType module, TTypeInfo typeInfo)
      : this ()
    {
      Name = module;

      TypeInfo.CopFrom (typeInfo);
    }

    protected TModuleInfo ()
    {
      TypeInfo = new TTypeInfo ();

      Id = Guid.NewGuid ();
    }
    #endregion

    #region Members
    public void Select (TTypeInfo typeInfo)
    {
      TypeInfo.CopFrom (typeInfo);
    }

    public void CopyFrom (TModuleInfo<TModuleType> alias)
    {
      if (alias.NotNull ()) {
        Name = alias.Name;
        TypeInfo.CopFrom (alias.TypeInfo);
        Id = alias.Id;
      }
    }

    public bool IsModule (TModuleType module)
    {
      return (Name.Equals (module));
    }
    #endregion
  }
  //---------------------------//

}  // namespace