﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Message
{
  #region Data
  //----- TRelation
  public enum TRelation
  {
    None,
    Parent,
    Child,
    Sibling,
    Module,
  };
  //---------------------------//
  #endregion

  //----- TNode
  public class TNode<C>
  {
    #region Property
    public TRelation Relation
    {
      get;
      private set;
    }

    public C Child
    {
      get;
      private set;
    }

    public bool IsRelationParent
    {
      get
      {
        return (Relation.Equals (TRelation.Parent));
      }
    }

    public bool IsRelationChild
    {
      get
      {
        return (Relation.Equals (TRelation.Child));
      }
    }

    public bool IsRelationSibling
    {
      get
      {
        return (Relation.Equals (TRelation.Sibling));
      }
    }
    #endregion

    #region Constructor
    public TNode (C child)
      : this ()
    {
      Child = child;
    }

    protected TNode ()
    {
      Relation = TRelation.None;
    }
    #endregion

    #region Members
    public void SelectRelationParent (C child)
    {
      Relation = TRelation.Parent;
      Child = child;
    }

    public void SelectRelationChild (C child)
    {
      Relation = TRelation.Child;
      Child = child;
    }

    public void SelectRelationSibling (C child)
    {
      Relation = TRelation.Sibling;
      Child = child;
    }

    public void SelectRelationModule (C child)
    {
      Relation = TRelation.Module;
      Child = child;
    }
    #endregion
  };
  //---------------------------//

}  // namespace