﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using rr.Library.Types;
//---------------------------//

namespace rr.Library.Message
{
  #region Data
  //----- TRelation
  public enum TRelation
  {
    None,
    Parent,
    Child,
    Sibling,
    Module,
  };
  //---------------------------//
  #endregion

  //----- TNode
  public class TNode<TChildType>
  {
    #region Property
    public TRelation Relation
    {
      get;
      private set;
    }

    public TChildType Child
    {
      get;
      private set;
    }

    public bool IsRelationParent
    {
      get
      {
        return (Relation.Equals (TRelation.Parent));
      }
    }

    public bool IsRelationChild
    {
      get
      {
        return (Relation.Equals (TRelation.Child));
      }
    }

    public bool IsRelationSibling
    {
      get
      {
        return (Relation.Equals (TRelation.Sibling));
      }
    }

    public TTypeInfo TypeInfo
    {
      get; 
    }
    #endregion

    #region Constructor
    public TNode (TChildType child, TTypeInfo typeInfo)
      : this ()
    {
      Child = child;
      TypeInfo.CopFrom (typeInfo);
    }

    protected TNode ()
    {
      Relation = TRelation.None;
      TypeInfo = new TTypeInfo ();
    }
    #endregion

    #region Members
    public void SelectRelationParent (TChildType child)
    {
      Relation = TRelation.Parent;
      Child = child;
    }

    public void SelectRelationChild (TChildType child)
    {
      Relation = TRelation.Child;
      Child = child;
    }

    public void SelectRelationSibling (TChildType child)
    {
      Relation = TRelation.Sibling;
      Child = child;
    }

    public void SelectRelationModule (TChildType child)
    {
      Relation = TRelation.Module;
      Child = child;
    }
    #endregion
  };
  //---------------------------//

}  // namespace