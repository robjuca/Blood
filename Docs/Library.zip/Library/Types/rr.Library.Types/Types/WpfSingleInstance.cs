﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
//---------------------------//

namespace rr.Library.Types
{
  #region Data
  public enum TSingleInstanceModes
  {
    /// <summary>
    /// Do nothing.
    /// </summary>
    NotInited = 0,

    /// <summary>
    /// Every user can have own single instance.
    /// </summary>
    ForEveryUser,
  }
  #endregion

  public static class TSingleInstance
  {
    /// <summary>
    /// Processing single instance in <see cref="TSingleInstanceModes"/> <see cref="TSingleInstanceModes.ForEveryUser"/> mode.
    /// </summary>
    public static void Make ()
    {
      Make (TSingleInstanceModes.ForEveryUser);
    }

    /// <summary>
    /// Processing single instance.
    /// </summary>
    /// <param name="singleInstanceModes"></param>
    internal static void Make (TSingleInstanceModes singleInstanceModes)
    {
      var appName = Application.Current.GetType ().Assembly.ManifestModule.ScopeName;

      var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent ();
      var keyUserName = windowsIdentity != null ? windowsIdentity.User.ToString () : String.Empty;

      // Be careful! Max 260 chars!
      var eventWaitHandleName = string.Format (
        "{0}{1}",
        appName,
        singleInstanceModes == TSingleInstanceModes.ForEveryUser ? keyUserName : String.Empty
      );

      try {
        using (var eventWaitHandle = EventWaitHandle.OpenExisting (eventWaitHandleName)) {
          // It informs first instance about other startup attempting.
          eventWaitHandle.Set ();
        }

        // Let's terminate this posterior startup.
        // For that exit no interceptions.
        Environment.Exit (0);
      }

      catch {
        // It's first instance.

        // Register EventWaitHandle.
        using (var eventWaitHandle = new EventWaitHandle (false, EventResetMode.AutoReset, eventWaitHandleName)) {
          ThreadPool.RegisterWaitForSingleObject (eventWaitHandle, OtherInstanceAttemptedToStart, null, Timeout.Infinite, false);
        }

        RemoveApplicationsStartupDeadlockForStartupCrushedWindows ();
      }
    }

    private static void OtherInstanceAttemptedToStart (Object state, Boolean timedOut)
    {
      RemoveApplicationsStartupDeadlockForStartupCrushedWindows ();

      Application.Current.Dispatcher.BeginInvoke (new Action (() =>
      {
        try {
          Application.Current.MainWindow.Activate ();
        }
        catch { }
      }));
    }

    internal static DispatcherTimer AutoExitAplicationIfStartupDeadlock;

    public static void RemoveApplicationsStartupDeadlockForStartupCrushedWindows ()
    {
      Application.Current.Dispatcher.BeginInvoke (new Action (() =>
        {
          AutoExitAplicationIfStartupDeadlock =
            new DispatcherTimer (
              TimeSpan.FromSeconds (6),
              DispatcherPriority.ApplicationIdle,
              (o, args) =>
              {
                if (Application.Current.Windows.Cast<Window> ().Count (window => !Double.IsNaN (window.Left)) == 0) {
                  // For that exit no interceptions.
                  Environment.Exit (0);
                }
              },
              Application.Current.Dispatcher
            );
        }),
        DispatcherPriority.ApplicationIdle
        );
    }
  }
  //---------------------------//

}  // namespace