﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System.Collections.Generic;
//---------------------------//

namespace rr.Library.Types
{
  //----- TRule
  public class TRule
  {
    #region Constructor
    TRule ()
    {
      Rules = new Dictionary<string, TRuleInfo> ();
    }
    #endregion

    #region Members
    public void Add (TRuleInfo ruleInfo)
    {
      if (ruleInfo.Equals (null).Equals (false)) {
        if (Rules.ContainsKey (ruleInfo.Name).Equals (false)) {
          Rules.Add (ruleInfo.Name, ruleInfo);
        }
      }
    }

    public void Remove (string ruleName)
    {
      if (Rules.ContainsKey (ruleName)) {
        Rules.Remove (ruleName);
      }
    }

    public bool IsCommit (string ruleName)
    {
      if (Rules.ContainsKey (ruleName)) {
        return (Rules [ruleName].IsCommit);
      }

      return (false);
    }

    public void Pump (string ruleName)
    {
      if (Rules.ContainsKey (ruleName)) {
        Rules [ruleName].Pump ();
      }
    }

    public void Unpump (string ruleName)
    {
      if (Rules.ContainsKey (ruleName)) {
        Rules [ruleName].Unpump ();
      }
    }
    #endregion

    #region Property
    Dictionary<string, TRuleInfo> Rules
    {
      get;
    } 
    #endregion

    #region Static
    public static TRule CreateDefault => new TRule ();
    #endregion
  };
  //---------------------------//

  //----- TRuleInfo
  public class TRuleInfo
  {
    #region Property
    public string Name
    {
      get;
    }

    public int CommitValue
    {
      get; 
    }

    public bool IsCommit
    {
      get
      {
        return (CommitValue.Equals (m_Count));
      }
    }
    #endregion

    #region Constructor
    TRuleInfo (string ruleName, int commitValue)
    {
      Name = ruleName;
      CommitValue = commitValue;

      m_Count = 0;
    }
    #endregion

    #region Members
    public void Pump ()
    {
      m_Count++;
    }

    public void Unpump ()
    {
      m_Count--;
    }
    #endregion

    #region Fields
    int                                     m_Count;
    #endregion

    #region Static
    public static TRuleInfo Create (string ruleName, int commitValue) => new TRuleInfo (ruleName, commitValue); 
    #endregion
  };
  //---------------------------//

}  // namespace