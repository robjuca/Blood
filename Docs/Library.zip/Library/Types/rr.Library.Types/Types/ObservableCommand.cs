﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Windows.Input;
//---------------------------//

namespace rr.Library.Types
{
  public class TObservableCommand : ObservableObject<ICommand>
  {
    #region Constructor
    public TObservableCommand (ICommand command)
    {
      Value = command;
    } 
    #endregion
  }
  //---------------------------//

}  // namespace