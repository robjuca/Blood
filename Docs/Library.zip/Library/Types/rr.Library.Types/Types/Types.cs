﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
//---------------------------//

namespace rr.Library.Types
{
  //----- TStatus
  public enum TStatus
  {
    None,
    Inside,                
    Closed,
    Standby,               
  };
  //---------------------------//

  //----- TViewState
  public enum TViewState
  {
    None,
    Hide,
    Show,
  };
  //---------------------------//

  //----- TViewMode
  public enum TViewMode
  {
    None,
    Edit,
  };
  //---------------------------//

  //-----TTypeInfo
  public class TTypeInfo
  {
    #region Property
    public string ClassName
    {
      get;
      private set;
    }

    public string MemberName
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TTypeInfo (string className, [System.Runtime.CompilerServices.CallerMemberName] string memberName = "")
    {
      ClassName = className;
      MemberName = memberName;
    }

    public TTypeInfo ()
    {
      ClassName = string.Empty;
      MemberName = string.Empty;
    }
    #endregion

    #region Members
    public bool IsSame (TTypeInfo alias)
    {
      if (alias != null) {
        return (ClassName.Equals (alias.ClassName, StringComparison.InvariantCulture));
      }

      return (false);
    }

    public void CopFrom (TTypeInfo alias)
    {
      if (alias != null) {
        ClassName = alias.ClassName;
        MemberName = alias.MemberName;
      }
    }
    #endregion
  };
  //---------------------------//

  //----- TDialogInfo
  public class TDialogInfo
  {
    public object RootModel
    {
      get; 
    }

    public string Content
    {
      get; 
    }
    #region Constructor
    public TDialogInfo (object rootModel, string content)
    {
      RootModel = rootModel;
      Content = content;
    }
    #endregion
  };
  //---------------------------//

  //----- TSeverity
  public enum TSeverity
  {
    Danger,
    Hight,
    Low,
    None,
    Normal,
  };
  //---------------------------//

  //----- TAuthentication
  public enum TAuthentication
  {
    None,
    SQL,
    Windows,
  };
  //---------------------------//

}  // namespace