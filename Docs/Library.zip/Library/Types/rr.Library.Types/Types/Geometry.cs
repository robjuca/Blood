﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Types
{
  public class TGeometry
  {
    #region Property
    public TPosition Position
    {
      get;
      private set;
    }

    public TSize Size
    {
      get;
      private set;
    }

    public string Color
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    TGeometry ()
    {
      Position = TPosition.CreateDefault;
      Size = TSize.CreateDefault;

      Color = "#ffffff"; // white
    }
    #endregion

    #region Members
    public void CopyFrom (TGeometry alias)
    {
      if (alias.Equals (null).Equals (false)) {
        Position.CopyFrom (alias.Position);
        Size.CopyFrom (alias.Size);

        Color = alias.Color;
      }
    }

    public void Select (string color)
    {
      Color = color;
    }
    #endregion

    #region Property
    public static TGeometry CreateDefault => new TGeometry ();
    #endregion
  };
  //---------------------------//

}  // namespace