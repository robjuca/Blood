﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Windows.Input;
//---------------------------//

namespace rr.Library.Types
{
  //----- AnotherCommandImplementation
  /// <summary>
  /// No WPF project is complete without it's own version of this.
  /// </summary>
  public class AnotherCommandImplementation : ICommand
  {
    #region Contructor
    public AnotherCommandImplementation (Action<object> execute) 
      : this (execute, null)
    {
    }

    public AnotherCommandImplementation (Action<object> execute, Func<object, bool> canExecute)
    {
      m_Execute = execute ?? throw new ArgumentNullException (nameof (execute));
      m_CanExecute = canExecute ?? (x => true);
    }
    #endregion

    #region Members
    public bool CanExecute (object parameter)
    {
      return (m_CanExecute (parameter));
    }

    public void Execute (object parameter)
    {
      m_Execute (parameter);
    }

    public void Refresh ()
    {
      CommandManager.InvalidateRequerySuggested ();
    }
    #endregion

    #region Event
    public event EventHandler CanExecuteChanged
    {
      add
      {
        CommandManager.RequerySuggested += value;
      }

      remove
      {
        CommandManager.RequerySuggested -= value;
      }
    } 
    #endregion

    #region Fields
    readonly Action<object>                           m_Execute;
    readonly Func<object, bool>                       m_CanExecute; 
    #endregion
  };
  //---------------------------//

  //----- DelegateCommand
  public class DelegateCommand : ICommand
  {
    #region Constructor
    public DelegateCommand (Action execute)
      : this (execute, null)
    {
    }

    public DelegateCommand (Action execute, Predicate<object> canExecute)
    {
      if (execute == null) {
        throw new ArgumentNullException ("execute");
      }

      m_Execute = new Action (execute);

      if (canExecute != null) {
        m_CanExecute = new Predicate<object> (canExecute);
      }
    }
    #endregion

    #region ICommand Members
    public event EventHandler CanExecuteChanged;

    public bool CanExecute (object parameter)
    {
      if (m_CanExecute == null) {
        return true;
      }

      return (m_CanExecute (parameter));
    }

    public void Execute (object parameter)
    {
      m_Execute ();
    }
    #endregion

    #region Members
    public void RaiseCanExecuteChanged ()
    {
      if (CanExecuteChanged != null) {
        CanExecuteChanged (this, null);
      }
    } 
    #endregion

    #region Fields
    readonly Predicate<object>                        m_CanExecute;
    readonly Action                                   m_Execute; 
    #endregion
  };
  //---------------------------//

  //----- DelegateCommand<T>
  public class DelegateCommand<T> : ICommand
  {
    #region onstructor
    public DelegateCommand (Action<T> execute)
      : this (execute, null)
    {
    }

    public DelegateCommand (Action<T> execute, Predicate<T> canExecute)
    {
      if (execute == null) {
        throw new ArgumentNullException ("execute");
      }

      m_Execute = new Action<T> (execute);

      if (canExecute != null) {
        m_CanExecute = new Predicate<T> (canExecute);
      }
    } 
    #endregion

    #region ICommand Members
    public event EventHandler CanExecuteChanged;

    public bool CanExecute (object parameter)
    {
      if (m_CanExecute == null) {
        return (true);
      }

      return (m_CanExecute ((T) parameter));
    }

    public void Execute (object parameter)
    {
      if (m_Execute != null) {
        m_Execute ((T) parameter);
      }
    }
    #endregion

    #region Members
    public void RaiseCanExecuteChanged ()
    {
      if (CanExecuteChanged != null) {
        CanExecuteChanged (this, null);
      }
    }
    #endregion

    #region Fields
    readonly Predicate<T>                             m_CanExecute;
    readonly Action<T>                                m_Execute; 
    #endregion
  };
  //---------------------------//

}  // namespace