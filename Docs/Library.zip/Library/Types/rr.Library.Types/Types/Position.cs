﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Types
{
  public class TPosition
  {
    #region Property
    public int Column
    {
      get;
      private set;
    }

    public int Row
    {
      get;
      private set;
    }

    public string Position
    {
      get;
      set;
    }
    #endregion

    #region Constructor
    TPosition ()
    {
      Column = -1;
      Row = -1;

      Position = string.Empty;
    }

    TPosition (int col, int row)
    {
      Column = col;
      Row = row;
    }

    TPosition (TPosition position)
    {
      CopyFrom (position);
    }
    #endregion

    #region Members
    public void Select (int col, int row)
    {
      Column = col;
      Row = row;
    }

    public void SelectColumn (int col)
    {
      Column = col;
    }

    public void SelectRow (int row)
    {
      Row = row;
    }

    public void CopyFrom (TPosition alias)
    {
      if (alias != null) {
        Column = alias.Column;
        Row = alias.Row;
        Position = alias.Position;
      }
    }

    public void CopyFrom (int col, int row)
    {
      Column = col;
      Row = row;
    }

    public bool IsPosition (int col, int row)
    {
      return (Column.Equals (col) && Row.Equals (row));
    }

    public bool IsPosition (TPosition alias)
    {
      return ((alias == null) ? false : IsPosition (alias.Column, alias.Row));
    }

    public static TPosition Create (TPosition position)
    {
      return (new TPosition (position));
    }

    public static TPosition Create (int col, int row)
    {
      return (new TPosition (col, row));
    }
    #endregion

    #region Static
    public static TPosition CreateDefault => new TPosition ();
    #endregion
  };
  //---------------------------//

}  // namespace