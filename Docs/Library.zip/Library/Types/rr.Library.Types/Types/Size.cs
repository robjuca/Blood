﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Types
{
  public class TSize
  {
    #region Property
    public int Columns
    {
      get;
      private set;
    }

    public int Rows
    {
      get;
      private set;
    }

    public int Width
    {
      get;
      set;
    }

    public int Height
    {
      get;
      set;
    }

    public bool IsEmpty
    {
      get
      {
        return (Columns.Equals (0) || Rows.Equals (0));
      }
    }
    #endregion

    #region Constructor
    TSize ()
    {
      Columns = 0;
      Rows = 0;

      Width = 0;
      Height = 0;
    }

    TSize (int cols, int rows)
    {
      Columns = cols;
      Rows = rows;
    }
    #endregion

    #region Members
    public void Select (int cols, int rows)
    {
      Columns = cols;
      Rows = rows;
    }

    public void SelectColumns (int cols)
    {
      Columns = cols;
    }

    public void SelectRows (int rows)
    {
      Rows = rows;
    }

    public void CopyFrom (TSize alias)
    {
      if (alias != null) {
        Columns = alias.Columns;
        Rows = alias.Rows;

        Width = alias.Width;
        Height = alias.Height;
      }
    }

    public void CopyFrom (int cols, int rows)
    {
      Columns = cols;
      Rows = rows;
    }

    public bool IsSize (int cols, int rows)
    {
      return (Columns.Equals (cols) && Rows.Equals (rows));
    }

    public bool IsSize (TSize alias)
    {
      return ((alias == null) ? false : IsSize (alias.Columns, alias.Rows));
    }
    #endregion

    #region Static
    public static TSize Create (int cols, int rows) => new TSize (cols, rows);

    public static TSize CreateDefault => new TSize ();
    #endregion
  };
  //---------------------------//

}  // namespace