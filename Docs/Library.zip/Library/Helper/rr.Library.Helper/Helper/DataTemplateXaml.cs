﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System.Windows;
//---------------------------//

namespace rr.Library.Helper
{
  public class TDataTemplateXaml
  {
    public static DataTemplate RequestTemplate (string xml)
    {
      string xaml = $"<DataTemplate>{xml}</DataTemplate>";

      var parserContext = new System.Windows.Markup.ParserContext ();
      parserContext.XmlnsDictionary.Add ("", "http://schemas.microsoft.com/winfx/2006/xaml/presentation");
      parserContext.XmlnsDictionary.Add ("x", "http://schemas.microsoft.com/winfx/2006/xaml");

      using (var memoryStream = new System.IO.MemoryStream (System.Text.Encoding.ASCII.GetBytes (xaml))) {
        return (System.Windows.Markup.XamlReader.Load (memoryStream, parserContext) as DataTemplate);
      }
    }
  };
  //---------------------------//

}  // namespace