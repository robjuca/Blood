﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
//---------------------------//

namespace rr.Library.Helper
{
  public static class THelper
  {
    #region Members
    public static void DispatcherLater (Action action)
    {
      Caliburn.Micro.Execute.BeginOnUIThread (action);
    }

    public static void DispatcherLaterAsync (Action action)
    {
      if (action.NotNull ()) {
        AsyncDispatcherLater (action)
          .ContinueWith (delegate
            {
              // ??
            }, 
            TaskScheduler.Default
        );
      }      
    }

    public static byte [] ImageToByteArray (System.Drawing.Image imageIn)
    {
      var array = Array.Empty<byte> ();

      if (imageIn.NotNull ()) {
        using (System.IO.MemoryStream ms = new System.IO.MemoryStream ()) {
          imageIn.Save (ms, System.Drawing.Imaging.ImageFormat.Jpeg);

          ms.ToArray ().CopyTo (array, 0);
        }
      }

      return (array);
    }

    public static byte [] BitmapImageToByteArray (System.Windows.Media.Imaging.BitmapImage imageIn)
    {
      using (System.IO.MemoryStream ms = new System.IO.MemoryStream ()) {
        System.Windows.Media.Imaging.JpegBitmapEncoder encoder = new System.Windows.Media.Imaging.JpegBitmapEncoder ();
        encoder.Frames.Add (System.Windows.Media.Imaging.BitmapFrame.Create (imageIn));
        encoder.Save (ms);

        return (ms.ToArray ());
      }
    }

    public static System.Drawing.Image ByteArrayToImage (byte [] byteArrayIn)
    {
      if (byteArrayIn.IsNull ()) {
        return (null);
      }

      using (System.IO.MemoryStream ms = new System.IO.MemoryStream (byteArrayIn)) {
        System.Drawing.Image returnImage = System.Drawing.Image.FromStream (ms);
        
        return (returnImage);
      }
    }

    public static System.Windows.Media.Imaging.BitmapImage ByteArrayToBitmapImage (Array byteArrayIn)
    {
      if (byteArrayIn.IsNull ()) {
        return (null);
      }

      byte [] array = new byte [byteArrayIn.Length];
      byteArrayIn.CopyTo (array, 0);

      System.IO.MemoryStream stream = new System.IO.MemoryStream (array);
      stream.Seek (0, System.IO.SeekOrigin.Begin);

      System.Windows.Media.Imaging.BitmapImage image = new System.Windows.Media.Imaging.BitmapImage ();
      image.BeginInit ();
      image.StreamSource = stream;
      image.EndInit ();

      return (image.Clone ());
    }

    public static System.Windows.Media.Imaging.BitmapImage ByteArrayToBitmapImage (byte [] byteArrayIn)
    {
      if (byteArrayIn.IsNull ()) {
        return (null);
      }

      System.IO.MemoryStream stream = new System.IO.MemoryStream (byteArrayIn);
      stream.Seek (0, System.IO.SeekOrigin.Begin);

      System.Windows.Media.Imaging.BitmapImage image = new System.Windows.Media.Imaging.BitmapImage ();
      image.BeginInit ();
      image.StreamSource = stream;
      image.EndInit ();

      return (image.Clone ());
    }

    public static System.Windows.Media.Imaging.BitmapImage ByteArrayToBitmapImage (Collection <byte> image)
    {
      if (image.NotNull ()) {
        if (image.Count > 0) {
          byte [] imageArray = new byte [image.Count];
          image.CopyTo (imageArray, 0);

          return (ByteArrayToBitmapImage (imageArray));
        }
      }

      return (null);
    }

    public static string ExceptionStringFormat (string title, Exception exception)
    {
      string msg = string.Empty;

      if (exception.NotNull ()) {
        msg = $"{title}{Environment.NewLine}{exception.Message}{Environment.NewLine}{exception.StackTrace}";

        if (exception.InnerException.NotNull ()) {
          msg = $"{title}{Environment.NewLine}{exception.Message}{Environment.NewLine}{exception.InnerException.Message}{Environment.NewLine}{exception.InnerException.StackTrace}";
        }
      }

      return (msg);
    }
    #endregion

    #region Support
    static async Task AsyncDispatcherLater (Action action)
    {
      try {
        Task task = Caliburn.Micro.Execute.OnUIThreadAsync (action);

        if (task == await Task.WhenAny (task).ConfigureAwait (false)) {
          // do nothing
        }
      }

      catch (Exception) {
      }
    }
    #endregion
  };
  //---------------------------//

}  // namespace