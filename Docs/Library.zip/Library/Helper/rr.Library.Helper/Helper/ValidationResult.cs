﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Helper
{
  public class TValidationResult
  {
    #region Property
    public object ErrorContent
    {
      get;
      private set;
    }

    public object SuccessContent
    {
      get;
      private set;
    }

    public bool IsValid
    {
      get;
      private set;
    }

    public static TValidationResult Success
    {
      get
      {
        return (new TValidationResult (true, null, null));
      }
    }

    public static TValidationResult Failure
    {
      get
      {
        return (new TValidationResult (false, "failure", "failure"));
      }
    }
    #endregion

    #region Constructor
    protected TValidationResult ()
    {
      IsValid = false;
      ErrorContent = null;
      SuccessContent = null;
    }

    public TValidationResult (object errorContent)
    {
      IsValid = false;
      ErrorContent = errorContent;
    }

    public TValidationResult (bool isValid, object errorContent, object successContent)
    {
      IsValid = isValid;
      ErrorContent = errorContent;
      SuccessContent = successContent;
    }
    #endregion

    #region Members
    public void CopyFrom (TValidationResult alias)
    {
      if (alias != null) {
        IsValid = alias.IsValid;
        ErrorContent = alias.ErrorContent;
        SuccessContent = alias.SuccessContent;
      }
    } 
    #endregion

    #region Property
    public static TValidationResult CreateDefault => new TValidationResult ();
    #endregion
  };
  //---------------------------//

}  // namespace