﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System.Globalization;

using MadMilkman.Ini;
//---------------------------//

namespace rr.Library.Helper
{
  public class TIniFileManager
  {
    #region Property
    public string FilePath
    {
      get;
      private set;
    }

    public string FileName
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TIniFileManager ()
    {
      var options = new IniOptions
      {
        SectionDuplicate = IniDuplication.Disallowed
      };

      IniFileManager = new IniFile (options);
      IniFileManager.ValueMappings.Add ("True", true);
      IniFileManager.ValueMappings.Add ("False", false);
    }
    #endregion

    #region Members
    public void SelectPath (string filePath, string fileName)
    {
      FilePath = filePath;
      FileName = fileName;
    }

    public TValidationResult ValidatePath ()
    {
      var result = TValidationResult.Success;

      if (string.IsNullOrWhiteSpace ((FilePath ?? "").ToString (CultureInfo.InvariantCulture)) || string.IsNullOrWhiteSpace ((FileName ?? "").ToString (CultureInfo.InvariantCulture))) {
        result = new TValidationResult ("FilePath or FileName is NULL or EMPTY!");
      }

      else {
        if (System.IO.Directory.Exists (FilePath).Equals (false)) {
          result = new TValidationResult ("FilePath does not exist!");
        }

        else {
          // file found
          if (IniFileExists ()) {
            if (IsIniFileManagerLoaded.Equals (false)) {
              var fullPath = System.IO.Path.Combine (FilePath, FileName);
              IniFileManager.Load (fullPath);
            }
          }

          else {
            result = new TValidationResult ("INI file does not exist!");
          }
        }
      }

      return (result);
    }

    public bool IniFileExists ()
    {
      var fullPath = System.IO.Path.Combine (FilePath, FileName);

      // INI file found
      return (System.IO.File.Exists (fullPath).Equals (true));
    }

    public bool ContainsSection (string sectionName)
    {
      return (IniFileManager.Sections.Contains (sectionName));
    }

    public object AddSection (string sectionName)
    {
      return (IniFileManager.Sections.Add (sectionName));
    }

    public static void AddTrailingComment (object token, string comment)
    {
      if (token is IniSection section) {
        section.TrailingComment.Text = comment; // comment.
      }
    }

    public bool ContainsKey (string sectionName, string keyName)
    {
      return (ContainsSection (sectionName) ? Section (sectionName).Keys.Contains (keyName) : false);
    }

    public static void AddKey (object token, string keyName, string keyValue)
    {
      if (token is IniSection section) {
        section.Keys.Add (keyName, keyValue);
      }
    }

    public string RequestKey (string section, string key)
    {
      return (Section (section).Keys [key].Value);
    }

    public void ChangeKey (string section, string key, string value)
    {
      Section (section).Keys [key].Value = value;
    }

    public void SaveChanges ()
    {
      var fullPath = System.IO.Path.Combine (FilePath, FileName);
      IniFileManager.Save (fullPath);
    }
    #endregion

    #region Property
    IniFile IniFileManager
    {
      get;
    }

    bool IsIniFileManagerLoaded
    {
      get
      {
        return (IniFileManager.Sections.Count > 0);
      }
    }

    IniSection Section (string section)
    {
      return (IniFileManager.Sections [section]);
    }
    #endregion

    #region Static
    public static TIniFileManager CreatDefault => new TIniFileManager (); 
    #endregion
  }
  //---------------------------//

}  // namespace