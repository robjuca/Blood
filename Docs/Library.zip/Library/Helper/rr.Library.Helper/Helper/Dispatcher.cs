﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;
//---------------------------//

namespace rr.Library.Helper
{
  #region Data
  public          delegate void ActionArg<TActionArgType> (TActionArgType arg);
  #endregion

  public static class TDispatcher
  {
    #region Members
    public static void Invoke (Action action)
    {
      m_Fifo.Enqueue (new TQueueItem (action));

      // Delegate for consuming 
      async void act ()
      {
        while (m_Fifo.TryDequeue (out TQueueItem queueItem)) {
          await Caliburn.Micro.Execute.OnUIThreadAsync (queueItem.Action).ConfigureAwait (false);
        }
      }

      Parallel.Invoke (act);
    }

    public static void BeginInvoke<TActionArgType> (ActionArg<TActionArgType> actionArg, TActionArgType arg)
    {
      // Delegate for consuming 
      async void act ()
      {
        await System.Windows.Application.Current.Dispatcher.BeginInvoke (actionArg, new object [] { arg });
      }

      Parallel.Invoke (act);
    }
    #endregion

    #region Fields
    static readonly ConcurrentQueue<TQueueItem>                      m_Fifo = new ConcurrentQueue<TQueueItem> ();
    #endregion

    #region Class
    class TQueueItem
    {
      #region Property
      public Action Action
      {
        get;
      }
      #endregion

      #region Constructor
      public TQueueItem (Action action)
      {
        Action = action;
      }
      #endregion
    }; 
    #endregion
  };
  //---------------------------//

}  // namespace