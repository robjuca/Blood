﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace System
{
  public static class TrrExtension
  {
    public static bool IsFalse (this System.Boolean someObject)
    {
      return (someObject.Equals (false));
    }

    public static bool IsEmpty (this System.Guid someObject)
    {
      return (someObject.Equals (Guid.Empty));
    }

    public static bool NotEmpty (this System.Guid someObject)
    {
      return ((someObject.Equals (Guid.Empty)).Equals (false));
    }

    public static bool IsNull (this System.Object someObject)
    {
      return (Equals (someObject, null));
    }

    public static bool NotNull (this System.Object someObject)
    {
      return (Equals (someObject, null).Equals (false));
    }

    public static bool NotEquals (this System.Object someObject1,  System.Object someObject2)
    {
      return (((someObject1 == null) ? false : someObject1.Equals (someObject2)).Equals (false));
    }

    public static void ThrowNull (this System.Object someObject)
    {
      if (Equals (someObject, null)) {
        throw (new ArgumentException (rr.Library.Helper.Properties.Resource.RES_NULL));
      }
    }
  };
  //---------------------------//

}  // namespace