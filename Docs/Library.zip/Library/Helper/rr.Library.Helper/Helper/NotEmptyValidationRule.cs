﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System.Globalization;
using System.Windows.Controls;
//---------------------------//

namespace rr.Library.Helper
{
  public class TNotEmptyValidationRule : ValidationRule
  {
    public override ValidationResult Validate (object value, CultureInfo cultureInfo)
    {
      return (string.IsNullOrWhiteSpace ((value ?? "").ToString ()) ? new ValidationResult (false, "Field is required.") : ValidationResult.ValidResult);
    }
  };
  //---------------------------//

}  // namespace