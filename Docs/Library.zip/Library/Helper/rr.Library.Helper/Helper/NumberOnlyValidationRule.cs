﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System.Globalization;
using System.Windows.Controls;
//---------------------------//

namespace rr.Library.Helper
{
  public class TNumberOnlyValidationRule : ValidationRule
  {
    public override ValidationResult Validate (object value, CultureInfo cultureInfo)
    {
      if (string.IsNullOrWhiteSpace ((value ?? "").ToString ())) {
        return (new ValidationResult (false, "Field is required."));
      }

      else {
        if (System.Text.RegularExpressions.Regex.IsMatch (value.ToString (), "[^0-9]")) {
          return (new ValidationResult (false, "Please enter only numbers."));
        }
      }

      return (ValidationResult.ValidResult);
    }
  };
  //---------------------------//

}  // namespace