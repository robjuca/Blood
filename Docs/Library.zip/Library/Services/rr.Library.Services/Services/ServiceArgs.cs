﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.ComponentModel;
//---------------------------//

namespace rr.Library.Services
{
  public delegate void ServiceCompleted<T> (TServiceArgs<T> arg);

  public class TServiceArgs<T>
  {
    #region Property
    /// <summary>
    /// Client callback method
    /// </summary>
    ServiceCompleted<T> CompletedCallback
    {
      get;
      set;
    }

    public string CompletedCallbackName
    {
      get
      {
        return ((CompletedCallback == null) ? string.Empty : CompletedCallback.Method.Name);
      }
    }

    /// <summary>
    /// Result from the web service
    /// </summary>
    public T Result
    {
      get;
      set;
    }

    /// <summary>
    /// Error exception returned by the web service
    /// </summary>
    public Exception Error
    {
      get;
      set;
    }

    /// <summary>
    /// Objet que l'on souhaite voir revenir au retour du web service
    /// </summary>
    public object UserState
    {
      get;
      set;
    }

    /// <summary>
    /// Test whether there was an error and if the result is null
    /// </summary>
    public bool IsResultNullOrError
    {
      get
      {
        return (Error != null || Result == null);
      }
    }

    /// <summary>
    /// DateTime of the web service call
    /// </summary>
    public DateTime BeginDateTime
    {
      get;
      set;
    }

    /// <summary>
    /// DateTime of the web service response
    /// </summary>
    public DateTime EndDateTime
    {
      get;
      set;
    }
    #endregion

    #region Constructor
    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="callback">Callback method</param>
    public TServiceArgs (ServiceCompleted<T> callback)
      : this (callback, null)
    {
    }

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="callback">Callback method</param>
    /// <param name="userState">Argument which can be retrieved when getting the response from the web service</param>
    public TServiceArgs (ServiceCompleted<T> callback, object userState)
    {
      this.CompletedCallback = callback;
      this.UserState = userState;
      BeginDateTime = DateTime.Now;
    } 
    #endregion

    #region Members
    /// <summary>
    /// Completes the web service response by calling the callback method and stuff
    /// </summary>
    /// <param name="result">Result from the web service</param>
    /// <param name="arg">Argument returned by the web service</param>
    public void Complete (T result, AsyncCompletedEventArgs arg)
    {
      EndDateTime = DateTime.Now;

      Result = result;

      if (arg != null) {
        Error = arg.Error;
      }

      CompletedCallback?.Invoke (this);

      CompletedCallback = null;
    } 
    #endregion
  };
  //---------------------------//

}  // namespace