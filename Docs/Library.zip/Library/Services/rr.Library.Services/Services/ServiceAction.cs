﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
//---------------------------//

namespace rr.Library.Services
{
  public class TServiceAction<T>
  {
    #region Property
    public TServiceArgs<T> ServiceArgs
    {
      get;
      private set;
    }

    public object Param
    {
      get;
      set;
    }
    #endregion

    #region Constructor
    public TServiceAction (object param, ServiceCompleted<T> callback)
    {
      Param = param;
      ServiceArgs = new TServiceArgs<T> (callback);
    }

    public TServiceAction (object param)
      : this (param, null)
    {
      
    }

    public TServiceAction (ServiceCompleted<T> callback)
      : this (null, callback)
    {
    }

    public TServiceAction ()
    {
    }
    #endregion
  };
  //---------------------------//

}  // namespace