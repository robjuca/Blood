﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Generic;
using System.Windows;

using Caliburn.Micro;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public class TViewModelKey<TModel> : TViewModel<TModel> , IViewAware
  {
    #region Constructor
    public TViewModelKey (TModel model)
      : base (model)
    {
      m_Views = new Dictionary<string, object> ();
    }
    #endregion

    #region IViewAware Members
    public event EventHandler<ViewAttachedEventArgs> ViewAttached;

    public virtual void AttachView (object view, object context = null)
    {
      if (view is FrameworkElement) {
        FrameworkElementView = view as FrameworkElement;

        if (ViewAttached != null) {
          ViewAttachedEventArgs args = new ViewAttachedEventArgs
          {
            View = view,
            Context = context
          };

          ViewAttached (this, args);
        }

        var key = FrameworkElementView.Tag as string;

        if (string.IsNullOrWhiteSpace ((key ?? "").ToString ()) == false) {
          if (m_Views.ContainsKey (key) == false) {
            m_Views.Add (key, view);
          }
        }
      }
    }

    public virtual object GetView (object context = null)
    {
      return (FrameworkElementView);
    }
    #endregion

    #region Members
    public void RefreshCollection (string resourceName, string key)
    {
      if (m_Views.ContainsKey (key)) {
        if ((m_Views [key] as FrameworkElement).FindResource (resourceName) is System.Windows.Data.CollectionViewSource collection) {
          collection.View.Refresh ();
        }
      }
    }
    #endregion

    #region Fields
    Dictionary<string, object>                        m_Views; 
    #endregion
  };
  //---------------------------//

}  // namespace