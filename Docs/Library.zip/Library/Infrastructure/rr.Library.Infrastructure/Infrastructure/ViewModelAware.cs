﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Windows;

using Caliburn.Micro;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public class TViewModelAware<TModel> : TViewModel<TModel> , IViewAware
  {
    #region Constructor
    public TViewModelAware (TModel model)
      : base (model)
    {
      ViewMode = TViewMode.None;
    }

    public TViewModelAware (IPresentation presentation, TModel model)
      : base (model)
    {
      if (presentation.NotNull ()) {
        presentation.RequestPresentationCommand (this);
        presentation.EventSubscribe (this);
      }

      ViewMode = TViewMode.None;
    }
    #endregion

    #region IViewAware Members
    public event EventHandler<ViewAttachedEventArgs> ViewAttached;

    public virtual void AttachView (object view, object context = null)
    {
      if (view is FrameworkElement) {
        FrameworkElementView = view as FrameworkElement;

        if (ViewAttached.NotNull ()) {
          ViewAttachedEventArgs args = new ViewAttachedEventArgs
          {
            View = view,
            Context = context
          };

          ViewAttached (this, args);
        }
      }
    }

    public virtual object GetView (object context = null)
    {
      return (FrameworkElementView);
    }
    #endregion

    #region Members
    public void RefreshCollection (string resourceName)
    {
      if (FrameworkElementView.NotNull ()) {
        if (FrameworkElementView.FindResource (resourceName) is System.Windows.Data.CollectionViewSource collection) {
          collection.View.Refresh ();
        }
      }
    }

    public void SelectViewMode (TViewMode mode)
    {
      ViewMode = mode;
    }

    public void ResetViewMode ()
    {
      ViewMode = TViewMode.None;
    }
    #endregion

    #region Property
    TViewMode ViewMode
    {
      get;
      set;
    }

    protected bool IsViewModeEdit
    {
      get
      {
        return (ViewMode.Equals (TViewMode.Edit));
      }
    }
    #endregion
  };
  //---------------------------//

}  // namespace