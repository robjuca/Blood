﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Infrastructure
{
  public abstract class TModuleInitBase : IModule
  {
    #region Constructor
    public TModuleInitBase ()
    {
    }
    #endregion

    #region IModule Members
    public virtual void Initialize ()
    {
    }
    #endregion
  };
  //---------------------------//

}  // namespace