﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

using Caliburn.Micro;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Infrastructure
{
  //----- TViewModel<TModel>
  public class TViewModel<TModel> : TViewModelPresentation
  {
    #region Property
    public TModel Model
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TViewModel (TModel model)
    {
      Model = model;
    }

    public TViewModel (FrameworkElement view, TModel model)
    {
      FrameworkElementView = view;
      Model = model;
    }
    #endregion

    #region Members
    protected void RaiseChanged ()
    {
      NotifyOfPropertyChange (() => Model);
    }

    protected void UpdateDataContext ()
    {
      if (FrameworkElementView != null) {
        FrameworkElementView.DataContext = FrameworkElementView.DataContext ?? this;
      }
    }

    protected Storyboard FindStoryboard (string resourceName)
    {
      if (FrameworkElementView != null) {
        if (FrameworkElementView.Resources.Contains (resourceName)) {
          return (FrameworkElementView.Resources [resourceName] as Storyboard);
        }
      }

      return (null);
    }

    protected void BeginStoryboard (string resourceName)
    {
      var storyboard = FindStoryboard (resourceName);

      if (storyboard is Storyboard) {
        storyboard.Begin ();
      }
    }

    protected void GoToVisualState (string stateName)
    {
      if (FrameworkElementView != null) {
        VisualStateManager.GoToState ((Control) FrameworkElementView, stateName, true);
      }
    }

    protected void ShowViewAnimation ()
    {
      if (ViewState == TViewState.Hide) {
        ViewState = TViewState.Show;
        GoToVisualState ("ShowViewAnimation");
      }
    }

    protected void HideViewAnimation ()
    {
      if (ViewState == TViewState.Show) {
        ViewState = TViewState.Hide;
        GoToVisualState ("HideViewAnimation");
      }
    }
    #endregion

    #region Property
    protected FrameworkElement FrameworkElementView
    {
      get;
      set;
    }
    
    protected string TypeName
    {
      get;
      set;
    }

    protected TTypeInfo TypeInfo
    {
      get
      {
        return (new TTypeInfo (TypeName));
      }
    }
    #endregion
  }
  //---------------------------//

  //----- TViewModelPresentation
  public class TViewModelPresentation : TChildViewModel, IViewModel
  {
    #region Constructor
    public TViewModelPresentation ()
    {
      ViewState = TViewState.Hide;
    }
    #endregion

    #region IViewModel Members
    public event EventHandler Loaded;

    public bool IsLoaded
    {
      get
      {
        return (m_IsLoaded);
      }

      protected set
      {
        m_IsLoaded = value;

        if (IsLoaded) {
          Loaded?.Invoke (this, EventArgs.Empty);
        }
      }
    }

    public void SetPresentationCommand (IPresentationCommand presentationCommand)
    {
      PresentationCommand = presentationCommand;

      Execute.OnUIThreadAsync (AllDone);
      Execute.OnUIThreadAsync (Initialize);
    }
    #endregion

    #region Overrides
    protected virtual void Initialize ()
    {
    }

    protected virtual void AllDone ()
    {
    }
    #endregion

    #region Property
    protected IPresentationCommand PresentationCommand
    {
      get;
      set;
    }

    protected TViewState ViewState
    {
      get;
      set;
    }
    #endregion

    #region Fields
    bool                                    m_IsLoaded;
    #endregion
  };
  //---------------------------//

  //----- TChildViewModel
  public class TChildViewModel : TViewModel
  {
    #region Property
    public bool UseChildViewModel
    {
      get; 
      set;
    }

    public bool IsEmptyChildViewModel
    {
      get
      {
        return (ChildViewModelCount.Equals (0));
      }
    }

    public int ChildViewModelCount
    {
      get
      {
        return (m_ChildViewModelCollection.Count);
      }
    }
    #endregion

    #region Constructor
    public TChildViewModel ()
    {
      UseChildViewModel = false;

      m_ChildViewModelCollection = new Dictionary<string, object> ();
    }
    #endregion

    #region Event
    public event EventHandler<EventArgs> ChildViewModelCollectionChanged;
    #endregion

    #region Members
    public void AddChildViewModel (string key, object view)
    {
      if (m_ChildViewModelCollection.ContainsKey (key).IsFalse ()) {
        m_ChildViewModelCollection.Add (key, view);

        ChildViewModelCollectionChanged?.Invoke (this, EventArgs.Empty);
      }
    }

    public void RemoveChildViewModel (string key)
    {
      if (m_ChildViewModelCollection.ContainsKey (key)) {
        m_ChildViewModelCollection.Remove (key);

        ChildViewModelCollectionChanged?.Invoke (this, EventArgs.Empty);
      }
    }

    public bool ContainsChildViewModel (string key)
    {
      return (m_ChildViewModelCollection.ContainsKey (key));
    }

    public void RequestChildViewModelCollection (Dictionary <string, object> childViewModelCollection)
    {
      if (childViewModelCollection.NotNull ()) {
        childViewModelCollection.Clear ();

        foreach (var item in m_ChildViewModelCollection) {
          childViewModelCollection.Add (item.Key, item.Value);
        }
      }
    }

    public object RequestChildViewModel (string childViewModelName)
    {
      if (ContainsChildViewModel (childViewModelName)) {
        return (m_ChildViewModelCollection [childViewModelName]);
      }

      return (null);
    }

    public void RequestChildViewModelNames (Collection<string> childViewModelNames)
    {
      if (childViewModelNames.NotNull ()) {
        childViewModelNames.Clear ();

        foreach (var item in m_ChildViewModelCollection) {
          childViewModelNames.Add (item.Key);
        }
      }
    }
    #endregion

    #region Fields
    Dictionary<string, object>              m_ChildViewModelCollection;
    #endregion
  }
  //---------------------------//

  //----- TViewModel
  public class TViewModel : PropertyChangedBase
  {
    #region Constructor
    public TViewModel ()
    {
    }
    #endregion
  }
  //---------------------------//

}  // namespace