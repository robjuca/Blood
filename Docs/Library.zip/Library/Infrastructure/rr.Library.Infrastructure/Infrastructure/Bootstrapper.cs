﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;
using System.Linq;
using System.Windows;

using Caliburn.Micro;

using rr.Library.Helper;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public class TBootstrapper<TRootViewType> : BootstrapperBase, IDisposable
  {
    #region Constructor
    public TBootstrapper ()
    {
      m_AggregateCatalog = new AggregateCatalog ();

      Initialize ();
    }
    #endregion

    #region Members
    public void Dispose ()
    {
      Dispose (true);
      GC.SuppressFinalize (this);
    }

    protected virtual void ConfigureCatalog ()
    {
    }

    protected void AddToCatalog (AssemblyCatalog catalog)
    {
      m_AggregateCatalog.Catalogs.Add (catalog);
    }

    protected virtual void Dispose (bool disposing)
    {
      if (m_IsDisposed) {
        return;
      }

      if (disposing) {
        // free managed resources
        m_ApplicationCatalog.Dispose ();
        m_AggregateCatalog.Dispose ();
        m_Container.Dispose ();
      }

      m_IsDisposed = true;
    }
    #endregion

    #region Overrides
    protected override void Configure ()
    {
      //this app
      m_ApplicationCatalog = new AggregateCatalog (AssemblySource.Instance.Select (x => new AssemblyCatalog (x)).OfType<ComposablePartCatalog> ());

      m_AggregateCatalog.Catalogs.Add (m_ApplicationCatalog);

      m_Container = new CompositionContainer (m_AggregateCatalog);

      var batch = new CompositionBatch ();

      batch.AddExportedValue<IWindowManager> (new WindowManager ());
      batch.AddExportedValue<IEventAggregator> (new EventAggregator ());
      batch.AddExportedValue (m_Container);

      m_Container.Compose (batch);

      ConfigureCatalog ();
    }

    protected override object GetInstance (Type serviceType, string key)
    {
      string contract = string.IsNullOrEmpty (key) ? AttributedModelServices.GetContractName (serviceType) : key;
      var exports = m_Container.GetExportedValues<object> (contract);

      if (exports.Any ()) {
        return (exports.First ());
      }

      throw (new Exception ($"Could not locate any instances of contract {contract}."));
    }

    protected override IEnumerable<object> GetAllInstances (Type serviceType)
    {
      return (m_Container.GetExportedValues<object> (AttributedModelServices.GetContractName (serviceType)));
    }

    public IEnumerable<object> GetAllInstances (string key)
    {
      return (m_Container.GetExportedValues<object> (key));
    }

    protected override void BuildUp (object instance)
    {
      m_Container.SatisfyImportsOnce (instance);
    }

    protected override void OnStartup (object sender, StartupEventArgs e)
    {
      base.OnStartup (sender, e);

      DisplayRootViewFor<TRootViewType> ();
    }

    protected override void OnUnhandledException (object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs eventArgs)
    {
      if (eventArgs.NotNull ()) {
        var msg = THelper.ExceptionStringFormat ("Warning", eventArgs.Exception);

        eventArgs.Handled = true;
        MessageBox.Show (msg, Properties.Resource.RES_FATAL_ERROR, MessageBoxButton.OK);

        if (Application.Current.NotNull ()) {
          Application.Current.Shutdown ();
        }
      }
    }
    #endregion

    #region Fields
    readonly AggregateCatalog                         m_AggregateCatalog;
    AggregateCatalog                                  m_ApplicationCatalog;
    CompositionContainer                              m_Container;
    bool                                              m_IsDisposed;
    #endregion
  };
  //---------------------------//

}  // namespace