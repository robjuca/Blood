﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using Caliburn.Micro;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public interface IPresentation
  {
    IViewModel ViewModel
    {
      get;
      set;
    }

    void          RequestPresentationCommand (IViewModel viewModel);
    void          EventSubscribe (IViewModel viewModel);
  };
  //---------------------------//

}  // namespace