﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public interface IPresentationCommand
  {
  }
  //---------------------------//

}  // namespace
