﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Windows;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public partial class ViewChildBase : System.Windows.Controls.UserControl
  {
    #region Event
    // Declare the delegate (if using non-generic pattern).
    public delegate void AliveEventHandler (object sender, EventArgs e);

    // Declare the event.
    public event AliveEventHandler Alive;
    #endregion

    #region Constructor
    public ViewChildBase ()
    {
      Loaded += OnLoaded;
    }
    #endregion

    #region View Event
    void OnLoaded (object sender, System.Windows.RoutedEventArgs e)
    {
      var viewModel = Caliburn.Micro.IoC.GetInstance (null, Name);

      if (viewModel.NotNull ()) {
        Caliburn.Micro.ViewModelBinder.Bind (viewModel, this, null);

        Alive?.Invoke (viewModel, EventArgs.Empty);
      }
    }
    #endregion
  }
  //---------------------------//

}  // namespace