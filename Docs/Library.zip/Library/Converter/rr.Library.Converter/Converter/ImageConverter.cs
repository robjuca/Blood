﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System.Windows.Media.Imaging;
//---------------------------//

namespace rr.Library.Converter
{
  public static class TImageConverter
  {
    public static BitmapImage ByteArrayToBitmap (byte [] byteArray)
    {
      var image = new BitmapImage ();

      if (byteArray != null) {
        using (var ms = new System.IO.MemoryStream (byteArray)) {
          image.BeginInit ();
          image.CacheOption = BitmapCacheOption.OnLoad;
          image.StreamSource = ms;
          image.EndInit ();
        }
      }

      return (image);
    }
  };
  //---------------------------//

}  // namespace