﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author:     Roberto Oliveira Jucá (rrSoft@pobox.com)
----------------------------------------------------------------*/

//----- Include
using System;
using System.Globalization;
using System.Windows.Data;
//---------------------------//

namespace rr.Library.Converter
{
  public class THexColorConverter : IValueConverter
  {
    #region IValueConverter Members
    public object Convert (object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value is string hex) {
        var color = System.Drawing.ColorTranslator.FromHtml (hex);
        var r = color.R;
        var g = color.G;
        var b = color.B;

        return (new System.Windows.Media.SolidColorBrush (System.Windows.Media.Color.FromRgb (r, g, b)));
      }

      return (new System.Windows.Media.SolidColorBrush (System.Windows.Media.Color.FromRgb (255, 255, 255)));
    }

    public object ConvertBack (object value, Type targetType, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException (Properties.Resource.RES_NOT_IMPLEMENTED);
    }
    #endregion
  };
  //---------------------------//

} // namespace