﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Globalization;
using System.Windows.Data;
//---------------------------//

namespace rr.Library.Converter
{
  public class TByteArrayToBitmapImageConverter : IValueConverter
  {
    #region IValueConverter Members
    public object Convert (object value, Type targetType, object parameter, CultureInfo culture)
    {
      return (TImageConverter.ByteArrayToBitmap (value as byte []));
    }
    
    public object ConvertBack (object value, Type targetType, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException (Properties.Resource.RES_NOT_IMPLEMENTED);
    }
    #endregion
  };
  //---------------------------//

}  // namespace