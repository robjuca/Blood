﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Activities.Presentation.Converters;
using System.Activities.Presentation.Model;
using System.Activities.Presentation.PropertyEditing;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using Microsoft.Win32;
//---------------------------//

namespace rr.Library.Controls
{
  //----- TextEditorBase
  public class TTextEditorBase : ExtendedPropertyValueEditor
  {
    #region Property
    public string NormalTemplate
    {
      get;
      set;
    }

    public string EditTemplate
    {
      get;
      set;
    }
    #endregion

    #region Constructor
    public TTextEditorBase ()
    {
      // Template for normal view
      NormalTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
            xmlns:pe='clr-namespace:System.Activities.Presentation.PropertyEditing;assembly=System.Activities.Presentation'>
            <DockPanel LastChildFill='True'>
                <pe:EditModeSwitchButton TargetEditMode='ExtendedPopup' Name='EditButton' DockPanel.Dock='Right' />
                <TextBlock Text='{Binding Value}' Margin='2,0,0,0' VerticalAlignment='Center'/>
            </DockPanel>
        </DataTemplate>"
      ;

    }
    #endregion

    #region Members
    public void LoadTemplate ()
    {
      // Load templates
      using MemoryStream msNornal = new MemoryStream (Encoding.UTF8.GetBytes (NormalTemplate));
      InlineEditorTemplate = XamlReader.Load (msNornal) as DataTemplate;

      using MemoryStream msExtended = new MemoryStream (Encoding.UTF8.GetBytes (EditTemplate));
      ExtendedEditorTemplate = XamlReader.Load (msExtended) as DataTemplate;
    }
    #endregion
  };
  //---------------------------//

  //----- TextEditorH60
  public class TTextEditorH60 : TTextEditorBase
  {
    #region Constructor
    public TTextEditorH60 ()
      : base ()
    {
      // Template for extended view. Shown when dropdown button is pressed.
      EditTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
            xmlns:sys='clr-namespace:System;assembly=mscorlib'>
            <StackPanel Orientation='Vertical' Background='White'>
                <TextBox Width='250'
                    HorizontalAlignment = 'Left'
                    Height='60'
                    TextWrapping = 'Wrap'
                    ScrollViewer.VerticalScrollBarVisibility = 'Auto' 
                    Text='{Binding Value}'/>
            </StackPanel>
        </DataTemplate>"
      ;

      LoadTemplate ();
    }
    #endregion
  };
  //---------------------------//

  //----- TextEditorH170
  public class TTextEditorH170 : TTextEditorBase
  {
    #region Constructor
    public TTextEditorH170 ()
      : base ()
    {
      // Template for extended view. Shown when dropdown button is pressed.
      EditTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
            xmlns:sys='clr-namespace:System;assembly=mscorlib'>
            <StackPanel Orientation='Vertical' Background='White'>
                <TextBox Width='250'
                    HorizontalAlignment = 'Left'
                    Height='170'
                    TextWrapping = 'Wrap'
                    ScrollViewer.VerticalScrollBarVisibility = 'Auto' 
                    Text='{Binding Value}'/>
            </StackPanel>
        </DataTemplate>"
      ;

      LoadTemplate ();
    }
    #endregion
  };
  //---------------------------//

  //----- TPictureEditor
  public class TPictureEditor : DialogPropertyValueEditor
  {
    #region Constructor
    public TPictureEditor ()
    {
      string template = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
            xmlns:pe='clr-namespace:System.Activities.Presentation.PropertyEditing;assembly=System.Activities.Presentation'>
            <DockPanel LastChildFill='True'>
                <pe:EditModeSwitchButton TargetEditMode='Dialog' Name='EditButton' DockPanel.Dock='Right'>...</pe:EditModeSwitchButton>
                <TextBlock Text='Picture' Margin='2,0,0,0' VerticalAlignment='Center'/>
            </DockPanel>
        </DataTemplate>";

      using var sr = new MemoryStream (Encoding.UTF8.GetBytes (template));
      InlineEditorTemplate = XamlReader.Load (sr) as DataTemplate;
    }
    #endregion

    #region Event
    public static event EventHandler Cleanup;

    void OnCleanup (object sender, EventArgs e)
    {
      if (Cleanup != null) {
         Cleanup.DynamicInvoke (this, EventArgs.Empty);
      }
    } 
    #endregion

    #region Overrides
    // Open the dialog to pick image, when the dropdown button is pressed 
    public override void ShowDialog (PropertyValue propertyValue, IInputElement commandSource)
    {
      var window = new TImagePickerWindow (propertyValue.Value as BitmapImage);
      window.Cleanup += OnCleanup;

      if (window.ShowDialog ().Equals (true)) {
        var ownerActivityConverter = new ModelPropertyEntryToOwnerActivityConverter ();
        ModelItem activityItem = ownerActivityConverter.Convert (propertyValue.ParentProperty, typeof (ModelItem), false, null) as ModelItem;

        using ModelEditingScope editingScope = activityItem.BeginEdit ();
        propertyValue.Value = window.TheImage;
        editingScope.Complete (); // commit the changes

        var control = commandSource as Control;
        var oldData = control.DataContext;

        control.DataContext = null;
        control.DataContext = oldData;
      }
    }
    #endregion
  };
  //---------------------------//

  //-----TImagePickerWindow
  public sealed class TImagePickerWindow : Window
  {
    // Window to show the current image and optionally pick a different one
    #region Property
    public BitmapImage TheImage
    {
      get;
      set;
    }

    public Image ImageControl
    {
      get;
      set;
    }
    #endregion

    #region Event
    public event EventHandler Cleanup;  
    #endregion

    #region Constructor
    public TImagePickerWindow (BitmapImage bitmap)
    {
      TheImage = bitmap;

      Title = "Select Image:";
      Width = 250;
      Height = 360;
      WindowStartupLocation = WindowStartupLocation.CenterOwner;
      WindowStyle = WindowStyle.ToolWindow;
      ResizeMode = ResizeMode.NoResize;
      ShowInTaskbar = false;

      var image = new Image
      {
        Width = 240,
        Height = 240,
        Stretch = Stretch.Uniform,
        HorizontalAlignment = HorizontalAlignment.Stretch,
        VerticalAlignment = VerticalAlignment.Stretch
      };

      var border = new Border
      {
        BorderThickness = new Thickness (1),
        BorderBrush = Brushes.DarkGray,
        HorizontalAlignment = HorizontalAlignment.Center,
        VerticalAlignment = VerticalAlignment.Top,
        Margin = new Thickness (5),
        Padding = new Thickness (2),
        Child = image
      };

      border.SetValue (Grid.RowProperty, 0);

      m_ImageInfo = new TextBlock
      {
        HorizontalAlignment = HorizontalAlignment.Center
      };

      m_ImageInfo.SetValue (Grid.RowProperty, 2);

      #region Button
      var button1 = new Button
      {
        Content = "Browse",
        Width = 80,
        FontSize = 12,
      };

      button1.SetValue (Grid.ColumnProperty, 0);
      button1.Click += new RoutedEventHandler (OnPickButtonClick);

      m_ApplyButton = new Button
      {
        Content = "Apply",
        Width = 80,
        FontSize = 12,
        Visibility = (bitmap == null) ? Visibility.Hidden : Visibility.Visible,
      };

      m_ApplyButton.SetValue (Grid.ColumnProperty, 1);
      m_ApplyButton.Click += new RoutedEventHandler (OnApplyButtonClick);

      m_CleanupButton = new Button
      {
        Content = "Cleanup",
        Width = 80,
        FontSize = 12,
        Visibility = (bitmap == null) ? Visibility.Hidden : Visibility.Visible,
      };

      m_CleanupButton.SetValue (Grid.ColumnProperty, 2);
      m_CleanupButton.Click += new RoutedEventHandler (OnCleanupButtonClick);

      var gridButton = new Grid
      {
        HorizontalAlignment = HorizontalAlignment.Center
      };

      gridButton.ColumnDefinitions.Add (new ColumnDefinition () { Width = new GridLength (1, GridUnitType.Auto) }); // column 0 button1
      gridButton.ColumnDefinitions.Add (new ColumnDefinition () { Width = new GridLength (1, GridUnitType.Auto) }); // column 1 button2
      gridButton.ColumnDefinitions.Add (new ColumnDefinition () { Width = new GridLength (1, GridUnitType.Auto) }); // column 2 button3

      gridButton.Children.Add (button1);
      gridButton.Children.Add (m_ApplyButton);
      gridButton.Children.Add (m_CleanupButton);

      gridButton.SetValue (Grid.RowProperty, 1);
      #endregion

      var grid = new Grid ();
      grid.RowDefinitions.Add (new RowDefinition () { Height = new GridLength (1, GridUnitType.Auto) }); // row 0 border
      grid.RowDefinitions.Add (new RowDefinition () { Height = new GridLength (1, GridUnitType.Auto) }); // row 1 button1,2,3
      grid.RowDefinitions.Add (new RowDefinition () { Height = new GridLength (1, GridUnitType.Auto) }); // row 2 imageInfo

      grid.Children.Add (border);
      grid.Children.Add (gridButton);
      grid.Children.Add (m_ImageInfo);

      AddChild (grid);

      ImageControl = image;

      if (bitmap != null) {
        ImageControl.Source = bitmap;

        m_ImageInfo.Text = string.Format ("width ({0}px) x height ({1}px)", TheImage.PixelWidth, TheImage.PixelHeight);
      }
    }
    #endregion

    #region Event
    void OnApplyButtonClick (object sender, RoutedEventArgs e)
    {
      DialogResult = true;
      Close ();
    }

    void OnPickButtonClick (object sender, RoutedEventArgs e)
    {
      OpenFileDialog dialog = new OpenFileDialog
      {
        CheckFileExists = true,
        DefaultExt = ".jpg",
        Filter = "Image Files (jpg jpeg)|*.jpg;*.jpeg",
        Multiselect = false,
        Title = "Select Image"
      };

      if (dialog.ShowDialog ().Equals (true)) {
        try {
          BitmapImage image = new BitmapImage ();
          image.BeginInit ();
          image.UriSource = new Uri (dialog.FileName, UriKind.RelativeOrAbsolute);
          image.EndInit ();

          TheImage = image;
          ImageControl.Source = image;

          m_ImageInfo.Text = string.Format ("width ({0}px) x height ({1}px)", TheImage.PixelWidth, TheImage.PixelHeight);

          m_ApplyButton.Visibility = Visibility.Visible;
          m_CleanupButton.Visibility = Visibility.Visible;
        }

        catch { }
      }
    }

    void OnCleanupButtonClick (object sender, RoutedEventArgs e)
    {
      Cleanup?.Invoke (this, EventArgs.Empty);

      DialogResult = true;
      Close ();
    }
    #endregion

    #region Fields
    readonly Button                                  m_ApplyButton;
    readonly Button                                  m_CleanupButton;
    readonly TextBlock                               m_ImageInfo;
    #endregion
  };
  //---------------------------//

  //----- TTextEditorStyle
  public class TTextEditorStyle : TTextEditorBase
  {
    #region Constructor
    public TTextEditorStyle ()
      : base ()
    {
      // Template for extended view. Shown when dropdown button is pressed.
      EditTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
            xmlns:sys='clr-namespace:System;assembly=mscorlib'>
            <StackPanel Orientation='Vertical' Background='White' Width='200'>
              <ComboBox Width='180' ItemsSource='{Binding Value.StyleItemsSource}' SelectedIndex='{Binding Value.StyleSelectedIndex, Mode=TwoWay}' >
                <ComboBox.ItemTemplate>
                  <DataTemplate>
                    <StackPanel Orientation='Horizontal' >
                      <TextBlock Text='{Binding StyleString}' />
                      <TextBlock Text='{Binding SizeString}' FontSize='8pt' Foreground='DimGray' Margin='3 0 0 0'/>
                    </StackPanel>
                  </DataTemplate>
                </ComboBox.ItemTemplate>
              </ComboBox>
            </StackPanel>
        </DataTemplate>"
      ;

      LoadTemplate ();
    }
    #endregion
  };
  //---------------------------//

  //----- TTextEditorImagePosition
  public class TTextEditorImagePosition : TTextEditorBase
  {
    #region Constructor
    public TTextEditorImagePosition ()
      : base ()
    {
      // Template for extended view. Shown when dropdown button is pressed.
      EditTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
            xmlns:sys='clr-namespace:System;assembly=mscorlib'>
            <StackPanel Orientation='Vertical' Background='White' Width='200'>
              <ComboBox Width='180' ItemsSource='{Binding Value.ImagePositionItemsSource}' SelectedIndex='{Binding Value.ImagePositionSelectedIndex, Mode=TwoWay}' >
                <ComboBox.ItemTemplate>
                  <DataTemplate>
                    <StackPanel Orientation='Horizontal'>
                      <TextBlock Text='{Binding Position}' />
                      <TextBlock Text='{Binding SizeString}' FontSize='8pt' Foreground='DimGray' Margin='3 0 0 0'/>
                    </StackPanel>
                  </DataTemplate>
                </ComboBox.ItemTemplate>
              </ComboBox>
            </StackPanel>
        </DataTemplate>"
      ;

      LoadTemplate ();
    }
    #endregion
  };
  //---------------------------//

  //----- TTextEditorVisibility
  public class TTextEditorVisibility : TTextEditorBase
  {
    #region Constructor
    public TTextEditorVisibility ()
      : base ()
    {
      // Template for extended view. Shown when dropdown button is pressed.
      EditTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
            xmlns:sys='clr-namespace:System;assembly=mscorlib'>
            <StackPanel Orientation='Vertical' Background='White' Width='200'>
              <StackPanel Orientation='Horizontal'>
                <RadioButton Content='visible' GroupName='{Binding Value.Client}'  Tag='0' IsChecked='{Binding Value.VisibleChecked, Mode=TwoWay}'  />
                <RadioButton Content='collapsed' GroupName='{Binding Value.Client}'  Tag='1' Margin='10 0 0 0' IsChecked='{Binding Value.CollapsedChecked, Mode=TwoWay}'   />
              </StackPanel>
            </StackPanel>
        </DataTemplate>"
      ;

      LoadTemplate ();
    }
    #endregion
  };
  //---------------------------//

  //----- TTextEditorInt4
  public class TTextEditorInt4 : TTextEditorBase
  {
    #region Constructor
    public TTextEditorInt4 ()
      : base ()
    {
      // Template for extended view. Shown when dropdown button is pressed.
      EditTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
            <StackPanel Orientation='Vertical' Background='White' Width='200'>
              <ComboBox Width='180' ItemsSource='{Binding Value.Int4ItemsSource}' SelectedIndex='{Binding Value.Int4SelectedIndex, Mode=TwoWay}' >
                <ComboBox.ItemTemplate>
                  <DataTemplate>
                    <StackPanel Orientation='Horizontal'>
                      <TextBlock Text='{Binding Int4String}' />
                    </StackPanel>
                  </DataTemplate>
                </ComboBox.ItemTemplate>
              </ComboBox>
            </StackPanel>
        </DataTemplate>"
      ;

      LoadTemplate ();
    }
    #endregion
  };
  //---------------------------//

  //----- TTextEditorComboBox
  public class TTextEditorComboBox : TTextEditorBase
  {
    #region Constructor
    public TTextEditorComboBox ()
      : base ()
    {
      // Template for extended view. Shown when dropdown button is pressed.
      EditTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
            <StackPanel Orientation='Vertical' Background='White' Width='200'>
              <ComboBox Width='180' ItemsSource='{Binding Value.ItemsSource}' SelectedIndex='{Binding Value.SelectedIndex, Mode=TwoWay}' >
                <ComboBox.ItemTemplate>
                  <DataTemplate>
                    <StackPanel Orientation='Horizontal'>
                      <TextBlock Text='{Binding ValueString}' Tag='{Binding Tag}' />
                    </StackPanel>
                  </DataTemplate>
                </ComboBox.ItemTemplate>
              </ComboBox>
            </StackPanel>
        </DataTemplate>"
      ;

      LoadTemplate ();
    }
    #endregion
  };
  //---------------------------//

  //----- TTextEditorDate
  public class TTextEditorDate : TTextEditorBase
  {
    #region Constructor
    public TTextEditorDate ()
      : base ()
    {
      // Template for extended view. Shown when dropdown button is pressed.
      EditTemplate = @"
        <DataTemplate
            xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
            xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
              <Calendar SelectedDate='{Binding Value.TheDate}'  />
        </DataTemplate>"
      ;

      LoadTemplate ();
    }
    #endregion
  };
  //---------------------------//

}  // namespace