﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Activities.Presentation;
using System.Activities.Presentation.Model;
using System.Activities.Presentation.View;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
//---------------------------//

namespace rr.Library.Controls
{
  #region Data
  public enum PropertySort
  {
    NoSort = 0,
    Alphabetical = 1,
    Categorized = 2,
    CategorizedAlphabetical = 3
  };
  #endregion

  /// <summary>WPF Native PropertyGrid class, uses Workflow Foundation's PropertyInspector</summary>
  public class TPropertyGrid : Grid
  {
    #region Properties
    /// <summary>Get or sets the selected object. Can be null.</summary>
    public object SelectedObject
    {
      get
      {
        return GetValue (SelectedObjectProperty);
      }

      set
      {
        SetValue (SelectedObjectProperty, value);
      }
    }

    /// <summary>XAML information with PropertyGrid's font and color information</summary>
    /// <seealso>Documentation for WorkflowDesigner.PropertyInspectorFontAndColorData</seealso>
    public string FontAndColorData
    {
      get
      {
        return (FontAndColorData);
      }

      set
      {
        if (value.NotNull ()) {
          m_FontAndColorData = value;
        }

        m_WorkflowDesigner.PropertyInspectorFontAndColorData = m_FontAndColorData;
      }
    }

    /// <summary>Shows the help description area on the bottom of the control</summary>
    public bool HelpVisible
    {
      get
      {
        return (bool) GetValue (HelpVisibleProperty);
      }

      set
      {
        SetValue (HelpVisibleProperty, value);
      }
    }

    /// <summary>Shows the toolbar on the top of the control</summary>
    public bool ToolbarVisible
    {
      get
      {
        return (bool) GetValue (ToolbarVisibleProperty);
      }

      set
      {
        SetValue (ToolbarVisibleProperty, value);
      }
    }

    public PropertySort PropertySort
    {
      get
      {
        return (PropertySort) GetValue (PropertySortProperty);
      }

      set
      {
        SetValue (PropertySortProperty, value);
      }
    }

    /// <summary>Get or sets the support bottom object. Can be null.</summary>
    public StackPanel SupportBottomObject
    {
      get
      {
        return (GetValue (SupportBottomObjectProperty) as StackPanel);
      }

      set
      {
        SetValue (SupportBottomObjectProperty, value);
      }
    }

    /// <summary>Get or sets the support right object. Can be null.</summary>
    public Grid SupportRightObject
    {
      get
      {
        return (GetValue (SupportRightObjectProperty) as Grid);
      }

      set
      {
        SetValue (SupportRightObjectProperty, value);
      }
    }

    /// <summary>Get or sets the model type label.</summary>
    public string ModelTypeLabel
    {
      get
      {
        return (GetValue (ModelTypeLabelProperty) as string);
      }

      set
      {
        SetValue (ModelTypeLabelProperty, value);
      }
    }
    #endregion

    #region Dependency Properties 
    public static readonly DependencyProperty SelectedObjectProperty =
        DependencyProperty.Register ("SelectedObject", typeof (object), typeof (TPropertyGrid),
        new FrameworkPropertyMetadata (null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, SelectedObjectPropertyChanged));

    public static readonly DependencyProperty HelpVisibleProperty =
        DependencyProperty.Register ("HelpVisible", typeof (bool), typeof (TPropertyGrid),
        new FrameworkPropertyMetadata (true, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, HelpVisiblePropertyChanged));

    public static readonly DependencyProperty ToolbarVisibleProperty =
        DependencyProperty.Register ("ToolbarVisible", typeof (bool), typeof (TPropertyGrid),
        new FrameworkPropertyMetadata (true, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, ToolbarVisiblePropertyChanged));

    public static readonly DependencyProperty PropertySortProperty =
        DependencyProperty.Register ("PropertySort", typeof (PropertySort), typeof (TPropertyGrid),
        new FrameworkPropertyMetadata (PropertySort.NoSort, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, PropertySortPropertyChanged));

    public static readonly DependencyProperty SupportBottomObjectProperty =
        DependencyProperty.Register ("SupportBottomObject", typeof (StackPanel), typeof (TPropertyGrid),
        new FrameworkPropertyMetadata (null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, SupportBottomObjectPropertyChanged));

    public static readonly DependencyProperty SupportRightObjectProperty =
        DependencyProperty.Register ("SupportRightObject", typeof (StackPanel), typeof (TPropertyGrid),
        new FrameworkPropertyMetadata (null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, SupportRightObjectPropertyChanged));

    public static readonly DependencyProperty ModelTypeLabelProperty =
        DependencyProperty.Register ("ModelTypeLabel", typeof (string), typeof (TPropertyGrid),
        new FrameworkPropertyMetadata (string.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, ModelTypeLabelPropertyChanged));
    #endregion

    #region Constructor
    /// <summary>Default constructor, creates the UIElements including a PropertyInspector</summary>
    public TPropertyGrid ()
    {
      ColumnDefinitions.Add (new ColumnDefinition ()); // col 0
      ColumnDefinitions.Add (new ColumnDefinition () { Width = new GridLength (1, GridUnitType.Auto) }); // col 1

      RowDefinitions.Add (new RowDefinition () { Height = new GridLength (1, GridUnitType.Star) }); // row 0 property model
      RowDefinitions.Add (new RowDefinition () { Height = new GridLength (1, GridUnitType.Auto) }); // row 1 help splitter
      RowDefinitions.Add (new RowDefinition () { Height = new GridLength (1, GridUnitType.Auto) });  // row 2 help
      RowDefinitions.Add (new RowDefinition () { Height = new GridLength (1, GridUnitType.Auto) }); // row 3 SupportBottom

      m_WorkflowDesigner = new WorkflowDesigner ();

      TextBlock title = new TextBlock ()
      {
        Visibility = Visibility.Visible,
        TextWrapping = TextWrapping.NoWrap,
        TextTrimming = TextTrimming.CharacterEllipsis,
        FontWeight = FontWeights.SemiBold,
        FontSize = 10
      };

      TextBlock descrip = new TextBlock ()
      {
        Visibility = Visibility.Visible,
        TextWrapping = TextWrapping.Wrap,
        TextTrimming = TextTrimming.CharacterEllipsis,
        FontSize = 10
      };

      DockPanel dock = new DockPanel ()
      {
        Visibility = Visibility.Visible,
        LastChildFill = false,
        Margin = new Thickness (3, 0, 3, 0)
      };

      title.SetValue (DockPanel.DockProperty, Dock.Top);

      dock.Children.Add (title);
      dock.Children.Add (descrip);

      m_HelpText = new Border ()
      {
        Visibility = Visibility.Visible,
        BorderBrush = SystemColors.ActiveBorderBrush,
        Background = SystemColors.ControlBrush,
        BorderThickness = new Thickness (1),
        Child = dock
      };

      m_Splitter = new GridSplitter ()
      {
        Visibility = Visibility.Visible,
        ResizeDirection = GridResizeDirection.Rows,
        Height = 3,
        HorizontalAlignment = HorizontalAlignment.Stretch
      };

      var inspector = m_WorkflowDesigner.PropertyInspectorView;
      inspector.Visibility = Visibility.Visible;
      inspector.SetValue (FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Stretch);
      inspector.SetValue (Grid.RowProperty, 0);
      inspector.SetValue (Grid.ColumnProperty, 0);

      m_Splitter.SetValue (Grid.RowProperty, 1);
      m_Splitter.SetValue (Grid.ColumnProperty, 0);

      m_HelpText.SetValue (Grid.RowProperty, 2);
      m_HelpText.SetValue (Grid.ColumnProperty, 0);

      Binding binding = new Binding ("Parent.Background");
      title.SetBinding (BackgroundProperty, binding);
      descrip.SetBinding (BackgroundProperty, binding);

      m_SupportBottomObject = new StackPanel ();
      m_SupportBottomObject.SetValue (Grid.RowProperty, 3);
      m_SupportBottomObject.SetValue (Grid.ColumnProperty, 0);

      m_SupportRightObject = new Grid ();
      m_SupportRightObject.SetValue (Grid.RowSpanProperty, 3);
      m_SupportRightObject.SetValue (Grid.ColumnProperty, 1);

      Children.Add (inspector);
      Children.Add (m_Splitter);
      Children.Add (m_HelpText);
      Children.Add (m_SupportBottomObject);
      Children.Add (m_SupportRightObject);

      Type inspectorType = inspector.GetType ();

      var props = inspectorType.GetProperties (
        BindingFlags.Public |
        BindingFlags.NonPublic |
        BindingFlags.Instance |
        BindingFlags.DeclaredOnly)
      ;

      var methods = inspectorType.GetMethods (
        BindingFlags.Public |
        BindingFlags.NonPublic |
        BindingFlags.Instance |
        BindingFlags.DeclaredOnly)
      ;

      m_RefreshMethod = inspectorType.GetMethod ("RefreshPropertyList",
        BindingFlags.NonPublic |
        BindingFlags.Instance |
        BindingFlags.DeclaredOnly)
      ;

      m_IsInAlphaViewMethod = inspectorType.GetMethod ("set_IsInAlphaView",
        BindingFlags.Public |
        BindingFlags.Instance |
        BindingFlags.DeclaredOnly)
      ;

      m_OnSelectionChangedMethod = inspectorType.GetMethod ("OnSelectionChanged",
        BindingFlags.Public |
        BindingFlags.Instance |
        BindingFlags.DeclaredOnly)
      ;

      m_SelectionTypeLabel = inspectorType.GetMethod ("get_SelectionTypeLabel",
        BindingFlags.Public |
        BindingFlags.NonPublic |
        BindingFlags.Instance |
        BindingFlags.DeclaredOnly)
        .Invoke (inspector, Array.Empty<object> ()) as TextBlock
      ;

      m_PropertyToolBar = inspectorType.GetMethod ("get_PropertyToolBar",
        BindingFlags.Public |
        BindingFlags.NonPublic |
        BindingFlags.Instance |
        BindingFlags.DeclaredOnly)
        .Invoke (inspector, Array.Empty<object> ()) as Control
      ;

      m_PropertyToolBar.Visibility = Visibility.Collapsed;

      inspectorType.GetEvent ("GotFocus")
        .AddEventHandler (this, Delegate.CreateDelegate (typeof (RoutedEventHandler), this, "GotFocusHandler", false))
      ;

      m_SelectionTypeLabel.Padding = new Thickness (0);
      m_SelectionTypeLabel.Margin = new Thickness (2, 0, 0, 0);
      m_SelectionTypeLabel.Text = string.Empty;
    }
    #endregion

    #region Events
    static void SelectedObjectPropertyChanged (DependencyObject source, DependencyPropertyChangedEventArgs e)
    {
      TPropertyGrid pg = source as TPropertyGrid;

      if (e.NewValue == null) {
        pg.m_OnSelectionChangedMethod.Invoke (pg.m_WorkflowDesigner.PropertyInspectorView, new object [] { null });
        pg.m_SelectionTypeLabel.Text = pg.ModelTypeLabel;
      }

      else {
        var context = new EditingContext ();

        var mtm = new ModelTreeManager (context);
        mtm.Load (e.NewValue);
        
        Selection selection = Selection.Select (context, mtm.Root);

        pg.m_OnSelectionChangedMethod.Invoke (pg.m_WorkflowDesigner.PropertyInspectorView, new object [] { selection });

        pg.m_SelectionTypeLabel.Visibility = Visibility.Visible;

        if (string.IsNullOrEmpty (pg.ModelTypeLabel)) {
          // not now
          //pg.m_SelectionTypeLabel.Text = e.NewValue.GetType ().Name;
          pg.m_SelectionTypeLabel.Visibility = Visibility.Collapsed;
        }

        context.Dispose ();
      }

      pg.ChangeHelpText (string.Empty, string.Empty);
    }

    static void HelpVisiblePropertyChanged (DependencyObject source, DependencyPropertyChangedEventArgs e)
    {
      TPropertyGrid pg = source as TPropertyGrid;

      if (e.NewValue != e.OldValue) {
        if (e.NewValue.Equals (true)) {
          pg.RowDefinitions [1].Height = new GridLength (3);
          pg.RowDefinitions [2].Height = new GridLength (pg.m_HelpTextHeight);
        }

        else {
          pg.m_HelpTextHeight = pg.RowDefinitions [2].Height.Value;
          //pg.RowDefinitions [1].Height = new GridLength (1, GridUnitType.Auto);
          //pg.RowDefinitions [2].Height = new GridLength (1, GridUnitType.Auto);
          pg.RowDefinitions [1].Height = new GridLength (0);
          pg.RowDefinitions [2].Height = new GridLength (0);
        }
      }
    }

    static void ToolbarVisiblePropertyChanged (DependencyObject source, DependencyPropertyChangedEventArgs e)
    {
      TPropertyGrid pg = source as TPropertyGrid;
      pg.m_PropertyToolBar.Visibility = e.NewValue.Equals (true) ? Visibility.Visible : Visibility.Collapsed;
    }

    static void PropertySortPropertyChanged (DependencyObject source, DependencyPropertyChangedEventArgs e)
    {
      TPropertyGrid pg = source as TPropertyGrid;
      PropertySort sort = (PropertySort) e.NewValue;

      bool isAlpha = (sort == PropertySort.Alphabetical || sort == PropertySort.NoSort);
      pg.m_IsInAlphaViewMethod.Invoke (pg.m_WorkflowDesigner.PropertyInspectorView, new object [] { isAlpha });
    }

    static void SupportBottomObjectPropertyChanged (DependencyObject source, DependencyPropertyChangedEventArgs e)
    {
      TPropertyGrid pg = source as TPropertyGrid;
      pg.m_SupportBottomObject.Children.Add ((UIElement) e.NewValue);
    }

    static void SupportRightObjectPropertyChanged (DependencyObject source, DependencyPropertyChangedEventArgs e)
    {
      TPropertyGrid pg = source as TPropertyGrid;
      pg.m_SupportRightObject.Children.Add ((UIElement) e.NewValue);
    }

    static void ModelTypeLabelPropertyChanged (DependencyObject source, DependencyPropertyChangedEventArgs e)
    {
      TPropertyGrid pg = source as TPropertyGrid;
      pg.m_SelectionTypeLabel.Text = pg.ModelTypeLabel;
    }
    #endregion

    #region Members
    /// <summary>Updates the PropertyGrid's properties</summary>
    public void RefreshPropertyList ()
    {
      Cleanup ();

      m_RefreshMethod.Invoke (m_WorkflowDesigner.PropertyInspectorView, new object [] { false });
    }

    public void ChangeModelTypeLabel (string label)
    {
      m_SelectionTypeLabel.Text = label;

      RefreshPropertyList ();
    }

    public void Cleanup ()
    {
      var obj = SelectedObject;
      SelectedObject = null;
      SelectedObject = obj;
    }
    #endregion

    #region Fields
    WorkflowDesigner                                            m_WorkflowDesigner;
    MethodInfo                                                  m_RefreshMethod;
    MethodInfo                                                  m_OnSelectionChangedMethod;
    MethodInfo                                                  m_IsInAlphaViewMethod;
    TextBlock                                                   m_SelectionTypeLabel;
    Control                                                     m_PropertyToolBar;
    StackPanel                                                  m_SupportBottomObject;
    Grid                                                        m_SupportRightObject;
    Border                                                      m_HelpText;
    GridSplitter                                                m_Splitter;
    double                                                      m_HelpTextHeight = 40;
    string                                                      m_FontAndColorData;
    #endregion

    #region Support
    /// <summary>Traps the change of focused property and updates the help text</summary>
    /// <param name="sender">Not used</param>
    /// <param name="args">Points to the source control containing the selected property</param>
    void GotFocusHandler (object sender, RoutedEventArgs args)
    {
      string title = string.Empty;
      string descrip = string.Empty;

      var theSelectedObject = GetValue (SelectedObjectProperty);

      if (theSelectedObject != null) {
        object data = (args.OriginalSource as FrameworkElement).DataContext;
        PropertyInfo propEntry = data.GetType ().GetProperty ("PropertyEntry");

        if (propEntry == null) {
          propEntry = data.GetType ().GetProperty ("ParentProperty");
        }

        if (propEntry != null) {
          object propEntryValue = propEntry.GetValue (data, null);
          string propName = propEntryValue.GetType ().GetProperty ("PropertyName").GetValue (propEntryValue, null) as string;
          title = propEntryValue.GetType ().GetProperty ("DisplayName").GetValue (propEntryValue, null) as string;
          PropertyInfo property = theSelectedObject.GetType ().GetProperty (propName);
          object [] attrs = property.GetCustomAttributes (typeof (DescriptionAttribute), true);

          if ((attrs != null) && (attrs.Length > 0)) {
            descrip = (attrs [0] as DescriptionAttribute).Description;
          }

          attrs = property.GetCustomAttributes (typeof (MaxLengthAttribute), true);

          if ((attrs != null) && (attrs.Length > 0)) {
            var text = args.OriginalSource as TextBox;

            if (text != null) {
              if (text.MaxLength == 0) {
                text.MaxLength = (attrs [0] as MaxLengthAttribute).Length;
              }
            }
          }
        }

        ChangeHelpText (title, descrip);
      }
    }

    /// <summary>Changes the text help area contents</summary>
    /// <param name="title">Title in bold</param>
    /// <param name="descrip">Description with ellipsis</param>
    void ChangeHelpText (string title, string descrip)
    {
      DockPanel dock = m_HelpText.Child as DockPanel;
      (dock.Children [0] as TextBlock).Text = title;
      (dock.Children [1] as TextBlock).Text = descrip;
    }
    #endregion
  }
};
//---------------------------//
